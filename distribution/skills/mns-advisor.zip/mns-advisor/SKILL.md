---
name: mns-advisor
description: 面向已安装 mns 命令行工具的通用投资助手技能。在任意工作目录、无项目源码的环境中，当用户询问基金或 ETF 定投、仓位再平衡、何时买入卖出、买入冷静期、账户复盘、恐贪情绪，或要求依据 mns 报告给出操作建议时使用。仅通过执行 mns 命令获取状态，不读取源码、不假设任何仓库路径；支持 macOS、Linux 与 Windows，随包提供 bash 与 PowerShell 两版只读采集脚本。Use when the user asks for DCA plans, rebalancing, buy or sell timing, portfolio review, or any decision based on mns output in an environment where mns is available on PATH.
agent_created: true
---

# mns-advisor

## 定位与前提

把 mns 当作一个已安装好的黑盒命令使用。它维护本地账户台账、给出目标仓位与偏离建议、生成决策报告。本技能负责编排命令、解读输出、把数字翻译成可执行的动作并留痕。

- 前提：`mns` 在 PATH 中。开始前先执行 `mns --version` 确认可用；不要寻找、读取或修改 mns 的源码、配置文件内部结构或任何仓库路径。Windows 上可执行文件为 `mns.exe`，命令与参数不变。
- **平台适配**：macOS / Linux 用 `scripts/collect_state.sh`（bash）；Windows 用 `scripts/collect_state.ps1`（PowerShell 5.1+ 或 7+，无需 bash、WSL 或 Python）。两份脚本输出契约一致，按宿主环境二选一，不要混用。
- 状态来自用户主目录下的 `.mns/`（Windows 为 `%USERPROFILE%\.mns\`），一律通过命令读写。账户尚未初始化时（`mns cash` 报错），先向用户说明并**请求确认**后再执行 `mns init`；持仓、现金、金额必须由用户提供，禁止编造或推测。
- mns 不代用户成交。所有买入、卖出、入金、出金、配置修改都要用户明确确认后，才执行对应命令补录台账。

## 三条红线

1. **情绪刻度不是买卖信号**。报告里的「决策分数 / 恐贪分区」只决定「这种状态下允许持有多少风险资产」，不决定今天买不买。工具自身声明不构成择时依据。禁止用新闻、研报、宏观观点、涨跌走势判断买卖方向，或据此覆盖分数、改写目标仓位。
2. **联网只用于核验执行条件**。合法用途是确认一笔已经获得授权的交易能否按计划落地：QDII 限购额度、申购费折扣、赎回费阶梯、T+n 结算与到账、交易日历、标的状态、基金公告。禁止用于择时、选标的、预测收益或替代规则。
3. **历史数字不是收益承诺**。`performance` 的回测对照栏、`backtest` 的收益与回撤都属于历史模拟和口径说明，不得表述为预期收益、胜率或推荐依据。

## 命令地图

| 意图 | 命令 | 副作用 |
|---|---|---|
| 一键采集账户状态 | macOS/Linux：`scripts/collect_state.sh`；Windows：`scripts/collect_state.ps1` | 只读 |
| 查看配置与可调参数 | `mns config`、`mns config params` | 只读 |
| 查看现金、持仓、绩效、流水 | `mns cash`、`mns portfolio`、`mns performance`、`mns history 20` | 只读 |
| 本月定投分配 | `mns plan --monthly <金额>` | 只读 |
| 买入冷静期 | `mns guard` | 只读 |
| 生成今日报告 | `mns today`（先刷价）、`mns report`（不刷价）、`--decide`、`--quiet` | **会写入本地快照并生成报告文件** |
| 账户对账 | `mns backtest mirror` | 只读 |
| 有效性检验 | `mns backtest`、`mns backtest validate-full --iterations 100` | 只读，耗时较长 |
| 数据更新 | `mns backtest update-data`、`mns update-prices`、`mns sentiment` | **会写入本地数据** |
| 台账维护 | `mns cash deposit/withdraw/set`、`mns add`、`mns buy`、`mns sell`、`mns price` | **会写入，需用户确认** |

不要使用已降级的 `mns backtest legacy` 与 `mns backtest validate`，它们的口径与实盘不一致。完整参数、输出字段与常见坑见 `references/command-cookbook.md`。

## 标准工作流

**第 0 步，采集状态**：按平台二选一，参数语义一致（`-Monthly` / `--monthly` 为月投额，`-SkipMirror` / `--skip-mirror` 跳过镜像对照）：

```text
# macOS / Linux
bash scripts/collect_state.sh --monthly 1000

# Windows PowerShell 5.1+
powershell -ExecutionPolicy Bypass -File .\scripts\collect_state.ps1 -Monthly 1000

# Windows PowerShell 7（推荐，UTF-8 默认）
pwsh -File ./scripts/collect_state.ps1 -Monthly 1000
```

脚本只调用只读命令，依次输出配置、现金、持仓、绩效、流水、冷静期、定投计划与账户镜像；任一命令失败会标注退出码并继续，不重试写命令。Windows 版已显式按 UTF-8 解码外部程序输出，避免中文乱码。

**每周决策日（默认周五）**：
1. 执行 `mns today` 取得带最新价格的报告；只需要重出报告、不想刷新价格时用 `mns report`。
2. 判断报告类型：决策版才含目标仓位、各腿偏离与买卖金额；观察版只描述状态，**结论必须是「今天不操作」**。
3. 读取报告中的年度交易预算与本年已交易笔数；预算用尽时不得新增建议。
4. 联网核验执行条件，输出决策卡，等用户确认后再补录 `mns buy` / `mns sell`。

**每月定投**：`mns cash deposit <金额>`（新钱到账，需确认）→ `mns plan --monthly <金额>` → `mns guard` → 输出决策卡。`plan` 只买不卖，金额是费用前估算。

**计划外临时买入**：先 `mns guard`。它只是减速带，不阻断交易、不改仓位。过热时输出「延迟 1 个交易日 + 写明理由」，不得把提示包装成看空结论。

**复盘或季度检查**：`mns performance` 看实际 XIRR 与实际最大回撤，需要对照严格执行结果时再跑 `mns backtest mirror`。完整审计 `mns backtest` 只在用户明确要求验证策略有效性时执行。

## 决策规则：何时允许动手

交易的合法性只来自可验证的事件，不来自对行情的判断。按 A → B → C 顺序判定：

| 触发器 | 判定 | 买 | 卖 |
|---|---|---|---|
| A 现金流事件 | 新钱到账 / 需要取钱 | 按 `mns plan` 的各腿缺口分配 | 现金够则出金；不够则减超配腿 |
| B 配置偏离 | 决策日例行检查 | 报告中的低配腿 | 报告中的超配腿 |
| C 计划外起意 | A、B 之外的临时想法 | 延迟 1 日 + 写理由 | 同左 |

- **C 不是第三种买入理由**，只是流程约束：只减速，不拦截。
- **情绪分数只作仓位刻度**，不决定买不买，也不产生止盈。
- 卖出理由只有两个：再平衡超配、需要用钱。不因高位清仓、不因浮亏割肉、不挑浮盈最多的标的卖。mns 没有「变现或出金该卖哪只」的专门命令，现金不足时依据报告的超配腿人工判断，并如实说明这是人工判断。
- **「不操作」是默认且主要的输出**：非决策日、偏离在带宽内、金额低于最小交易额、数据过期、预算用尽、未满最短持有天数，一律不动。节奏约为每周看一次、每月买一次、再平衡卖出可能一季度都没有。
- 不要把回测或护栏统计包装成「能提高收益」。这套方法的价值在于每笔交易有可追溯理由、不被单日行情改写；衡量指标是纪律执行率、非计划交易数、受阻与费用，不是收益率。

完整判定链、联网核验清单、决策卡模板与留痕格式见 `references/decision-playbook.md`，留痕模板见 `assets/decision-record.md`。

## 输出纪律

- 决策卡必须区分「事实」（来自哪条命令、哪个字段）与「推断」（Agent 的判断、联网核验结果），各自标注来源与日期。
- 明确写出执行前提与不确定性；缺少数据时说「数据不足，不产生建议」，不要用常识补齐。
- 结尾附一句边界说明：本输出是账户纪律与执行辅助，不构成投资建议、不承诺收益。
- 涉及金额、标的、份额、日期一律照抄命令输出，不四舍五入改写，不凭记忆填写。

## 失败处理

| 现象 | 处理 |
|---|---|
| `mns` 不在 PATH / `--version` 失败 | 停止，报告环境缺少 mns，不得改用其他数据源冒充 |
| 账户未初始化 | 请求用户确认后执行 `mns init`，不得自行写入初始现金或持仓 |
| 报告顶部有数据过期或降级警告 | 只按观察版解读；此时 `--decide` 不可用，不要重试或用旧数据推断 |
| 价格陈旧警告 | 提示先 `mns update-prices`（需确认），或明确标注金额可能失真 |
| `mns plan` 报错 | 检查 `mns config cashflow.monthly`；为 0 时显式传 `--monthly <用户给的值>`，不要猜金额 |
| `backtest` / `update-data` 失败 | 跳过并说明数据未就绪，不重试写命令、不自行编造数据 |
| 任何写入命令返回非 0 | 停止，报告错误，不重复执行（避免重复记账） |
| Windows 下中文乱码或脚本无法执行 | 改用 `collect_state.ps1`（不是 `.sh`）；优先用 PowerShell 7 (`pwsh`)；不要用 WSL 中的 mns 结果冒充 Windows 账户数据，两者数据目录不同 |

`backtest` 系列输出中若出现本地数据文件路径、历史区间或数据质量提示，那是工具的口径说明，不是需要访问的资源，也不要据此推断实盘收益。

## 资源

- `references/command-cookbook.md` — 每条命令的用途、参数、输出字段读法、副作用与常见坑。
- `references/decision-playbook.md` — 买卖判定链、联网核验清单、决策卡模板、复盘指标与禁用话术。
- `scripts/collect_state.sh` — macOS / Linux 一次性只读采集账户状态。
- `scripts/collect_state.ps1` — Windows 一次性只读采集账户状态（PowerShell 5.1+ / 7+）。
- `assets/decision-record.md` — 每笔决策的留痕模板。
