﻿<#
一次性只读采集 mns 账户状态（Windows PowerShell 5.1 / PowerShell 7+）。
只调用白名单内的只读子命令；不写任何文件，不改变账户、价格或配置。
与 collect_state.sh 的输出分段、字段与参数语义保持一致。

用法:
  powershell -ExecutionPolicy Bypass -File .\collect_state.ps1 -Monthly 1000
  powershell -ExecutionPolicy Bypass -File .\collect_state.ps1 -SkipMirror
  pwsh -File ./collect_state.ps1 -Monthly 1000
#>
param(
    [string]$Monthly = "",
    [switch]$SkipMirror,
    [switch]$Help
)

$ErrorActionPreference = "Continue"

# mns 输出含中文与制表符。Windows PowerShell 5.1 默认按系统 ANSI 代码页解码
# 外部程序输出，会导致中文乱码；显式按 UTF-8 读写可避免。
$utf8 = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

function Show-Usage {
    Write-Output "用法: collect_state.ps1 [-Monthly <金额>] [-SkipMirror]"
    Write-Output ""
    Write-Output "  -Monthly <金额>   生成对应金额的只读定投计划；省略时读取配置里的月投额，"
    Write-Output "                     若为 0 则跳过并提示向用户确认金额"
    Write-Output "  -SkipMirror       跳过账户镜像对照（输出更短）"
    Write-Output "  -Help             显示本说明"
    Write-Output ""
    Write-Output "只调用只读命令。生成报告、刷新价格、补录台账等写入操作不在本脚本范围内。"
}

function Write-Section {
    param([string]$Label)
    Write-Output ""
    Write-Output ("===== " + $Label + " =====")
}

function Invoke-ReadOnly {
    param([string]$Label, [string[]]$MnsArgs)
    Write-Section $Label
    try {
        $text = (& $script:MnsExe @MnsArgs 2>&1 | Out-String -Width 4096)
        $code = $LASTEXITCODE
        if ($null -eq $text) { $text = "" }
        Write-Output $text.TrimEnd()
        if ($null -ne $code -and $code -ne 0) {
            Write-Output ("[命令失败，退出码 " + $code + "；已跳过该项，不重试]")
        }
    } catch {
        Write-Output ("[命令执行异常：" + $_.Exception.Message + "；已跳过该项]")
    }
}

if ($Help) {
    Show-Usage
    exit 0
}

if ($Monthly -ne "" -and $Monthly -notmatch '^[0-9]+(\.[0-9]+)?$') {
    Write-Output "ERROR: -Monthly 需要一个数字金额"
    exit 2
}

# 二进制定位，顺序与 SKILL.md 的「二进制定位」一致：
#   $env:MNS_BIN → 安装目录 → PATH。
# 安装目录优先于 PATH：随包 CLI 与 GUI 同版本发布，PATH 上可能残留旧副本。
function Resolve-Mns {
    if ($env:MNS_BIN -and (Test-Path -LiteralPath $env:MNS_BIN -PathType Leaf)) {
        return (Resolve-Path -LiteralPath $env:MNS_BIN).Path
    }
    $candidates = @()
    if ($env:LOCALAPPDATA) {
        $candidates += (Join-Path $env:LOCALAPPDATA "Programs\MNS\mns.exe")
    }
    if (${env:ProgramFiles}) {
        $candidates += (Join-Path ${env:ProgramFiles} "MNS\mns.exe")
    }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    $cmd = Get-Command mns -ErrorAction SilentlyContinue
    if ($null -ne $cmd) { return $cmd.Source }
    return $null
}

$script:MnsExe = Resolve-Mns
if ($null -eq $script:MnsExe) {
    Write-Output "ERROR: 未找到 mns。已依次尝试 MNS_BIN、%LOCALAPPDATA%\Programs\MNS\mns.exe、%ProgramFiles%\MNS\mns.exe、PATH。"
    Write-Output "       请安装 MNS（CLI 随包提供），或设置环境变量 MNS_BIN；不要用其他数据源冒充账户数据。"
    exit 1
}

Invoke-ReadOnly -Label "版本" -MnsArgs @("--version")
Invoke-ReadOnly -Label "当前配置" -MnsArgs @("config")
Invoke-ReadOnly -Label "可调参数" -MnsArgs @("config", "params")
Invoke-ReadOnly -Label "现金余额与最近流水" -MnsArgs @("cash")
Invoke-ReadOnly -Label "持仓概览" -MnsArgs @("portfolio")
Invoke-ReadOnly -Label "组合绩效" -MnsArgs @("performance")
Invoke-ReadOnly -Label "最近 20 条流水" -MnsArgs @("history", "20")
Invoke-ReadOnly -Label "买入冷静期" -MnsArgs @("guard")

if ([string]::IsNullOrWhiteSpace($Monthly)) {
    $cfgText = (& $script:MnsExe config cashflow.monthly 2>&1 | Out-String -Width 4096)
    if ($null -eq $cfgText) { $cfgText = "" }
    $match = [regex]::Match($cfgText, '=\s*([0-9]+(?:\.[0-9]+)?)')
    if ($match.Success -and $match.Groups[1].Value -notmatch '^0+(\.0+)?$') {
        $Monthly = $match.Groups[1].Value
    }
}

if (-not [string]::IsNullOrWhiteSpace($Monthly)) {
    Invoke-ReadOnly -Label ("定投计划（月投 ¥" + $Monthly + "，只读）") -MnsArgs @("plan", "--monthly", $Monthly)
} else {
    Write-Section "定投计划"
    Write-Output "[跳过：未提供 -Monthly，且配置中的月投额为 0。请向用户确认金额后单独执行 mns plan --monthly <金额>]"
}

if (-not $SkipMirror) {
    Invoke-ReadOnly -Label "账户镜像对照" -MnsArgs @("backtest", "mirror")
}

Write-Section "采集结束"
Write-Output "以上全部为只读输出。任何写入类操作需用户明确确认后单独执行。"
