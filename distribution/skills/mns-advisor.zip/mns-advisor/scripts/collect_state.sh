#!/usr/bin/env bash
# 一次性只读采集 mns 账户状态（macOS / Linux）。
# 只调用白名单内的只读子命令；不写任何文件，不改变账户、价格或配置。
# Windows 请使用同目录的 collect_state.ps1（无需 bash）。
# 用法: collect_state.sh [--monthly <金额>] [--skip-mirror]

set -u

MONTHLY=""
SKIP_MIRROR=0

usage() {
  cat <<'EOF'
用法: collect_state.sh [--monthly <金额>] [--skip-mirror]

  --monthly <金额>   生成对应金额的只读定投计划；省略时读取配置里的月投额，
                     若为 0 则跳过并提示向用户确认金额
  --skip-mirror      跳过账户镜像对照（输出更短）

只调用只读命令。生成报告、刷新价格、补录台账等写入操作不在本脚本范围内。
Windows 请使用 collect_state.ps1，本脚本依赖 bash。
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --monthly)
      MONTHLY="${2:-}"
      if [ -z "$MONTHLY" ]; then echo "ERROR: --monthly 需要一个金额" >&2; exit 2; fi
      shift 2
      ;;
    --monthly=*)
      MONTHLY="${1#*=}"
      shift
      ;;
    --skip-mirror)
      SKIP_MIRROR=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "ERROR: 未知参数 $1" >&2
      usage
      exit 2
      ;;
  esac
done

# 二进制定位，顺序与 SKILL.md 的「二进制定位」一致：
#   $MNS_BIN → 应用包内 CLI → PATH。
# 应用包优先于 PATH：随包 CLI 与 GUI 同版本发布，PATH 上可能残留旧副本。
resolve_mns() {
  if [ -n "${MNS_BIN:-}" ] && [ -x "${MNS_BIN}" ]; then
    printf '%s' "${MNS_BIN}"
    return 0
  fi
  for candidate in \
    "/Applications/MNS.app/Contents/MacOS/mns" \
    "$HOME/Applications/MNS.app/Contents/MacOS/mns"
  do
    if [ -x "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  if command -v mns >/dev/null 2>&1; then
    command -v mns
    return 0
  fi
  return 1
}

MNS="$(resolve_mns)" || {
  printf '%s\n' "ERROR: 未找到 mns。已依次尝试 \$MNS_BIN、/Applications/MNS.app/Contents/MacOS/mns、~/Applications/MNS.app/Contents/MacOS/mns、PATH。" >&2
  printf '%s\n' "       请安装 MNS.app（CLI 随包提供）或显式设置 MNS_BIN；不要用其他数据源冒充账户数据。" >&2
  exit 1
}

section() {
  printf '\n===== %s =====\n' "$1"
}

run() {
  label="$1"
  shift
  section "$label"
  output="$("$@" 2>&1)"
  rc=$?
  printf '%s\n' "$output"
  if [ "$rc" -ne 0 ]; then
    printf '[命令失败，退出码 %s；已跳过该项，不重试]\n' "$rc"
  fi
}

run "版本" "$MNS" --version
run "当前配置" "$MNS" config
run "可调参数" "$MNS" config params
run "现金余额与最近流水" "$MNS" cash
run "持仓概览" "$MNS" portfolio
run "组合绩效" "$MNS" performance
run "最近 20 条流水" "$MNS" history 20
run "买入冷静期" "$MNS" guard

if [ -z "$MONTHLY" ]; then
  cfg="$("$MNS" config cashflow.monthly 2>/dev/null || true)"
  val="$(printf '%s\n' "$cfg" | awk -F'=' 'NF>=2 {gsub(/[[:space:]]/, "", $2); print $2}' | tail -1)"
  case "$val" in
    ''|*[!0-9.]*) val="0" ;;
  esac
  if awk -v v="$val" 'BEGIN { exit !(v > 0) }'; then
    MONTHLY="$val"
  fi
fi

if [ -n "$MONTHLY" ]; then
  run "定投计划（月投 ¥${MONTHLY}，只读）" "$MNS" plan --monthly "$MONTHLY"
else
  section "定投计划"
  printf '%s\n' "[跳过：未提供 --monthly，且配置中的月投额为 0。请向用户确认金额后单独执行 mns plan --monthly <金额>]"
fi

if [ "$SKIP_MIRROR" -eq 0 ]; then
  run "账户镜像对照" "$MNS" backtest mirror
fi

section "采集结束"
printf '%s\n' "以上全部为只读输出。任何写入类操作需用户明确确认后单独执行。"
